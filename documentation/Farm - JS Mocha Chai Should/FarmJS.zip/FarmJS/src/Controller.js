var Controller = function () {
    'use strict';
};

Controller.prototype.setup = function () {
    'use strict';
    var theFarm;
    theFarm = new Farm();
    // ADD CODE HERE TO CREATE THE FARM WORKERS

      /*
       First Name  Last Name  Main Job Gender       
       Bobby		Elba      shearer	M		
	   Selene		Mocha     labourer  F
	   Idris 		Kim		  farmhand  M
	   Jasmine 		Patel	  labourer  F	    
	  */
   
 
   //ADD CODE HERE TO CREATE THE FARM ANIMALS
	
	/*
	
        Type    	Food   		Total No  Breed     			Eats Humans 
        Sheep   	Grass    	320       Merino     			false
		Crocodile	sheep    	50		  Crocodylus Porosus	true
		Panda Ant	Nectar/meat 1000	  Mutillidae			true
		Dog			Meat		10		  Huntaway				false
		Anaconda	Meat		5		  Eunectes murinus		true
		
 */
  
    return theFarm;
};
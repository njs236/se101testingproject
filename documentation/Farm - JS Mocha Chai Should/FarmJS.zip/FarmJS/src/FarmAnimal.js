var FarmAnimal = function (newType, newFood, newTotalNumber, newBreed, newCanEatHuman, theFarm) {
    'use strict';
   
};


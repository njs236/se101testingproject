
/*globals describe beforeEach Controller it expects Farm, FarmWorker FarmAnimal*/
describe("Question One", function () {
    'use strict';
    it("Draw a class diagram", function () {} );
});
var  isVowelV4 = function ( letter ) {
    return;
};


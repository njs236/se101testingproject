var  isVowelV1 = function ( letter ) {
    return;
};

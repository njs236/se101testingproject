var  isVowelV3 = function ( letter ) {
    return;
};


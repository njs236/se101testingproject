var  isVowelV2 = function ( letter ) {
    return;
};